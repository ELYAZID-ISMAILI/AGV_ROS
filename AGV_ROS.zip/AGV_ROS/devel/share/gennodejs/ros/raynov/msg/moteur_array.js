// Auto-generated. Do not edit!

// (in-package raynov.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class moteur_array {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.vitesse1 = null;
      this.vitesse2 = null;
      this.vitesse3 = null;
      this.vitesse4 = null;
    }
    else {
      if (initObj.hasOwnProperty('vitesse1')) {
        this.vitesse1 = initObj.vitesse1
      }
      else {
        this.vitesse1 = 0;
      }
      if (initObj.hasOwnProperty('vitesse2')) {
        this.vitesse2 = initObj.vitesse2
      }
      else {
        this.vitesse2 = 0;
      }
      if (initObj.hasOwnProperty('vitesse3')) {
        this.vitesse3 = initObj.vitesse3
      }
      else {
        this.vitesse3 = 0;
      }
      if (initObj.hasOwnProperty('vitesse4')) {
        this.vitesse4 = initObj.vitesse4
      }
      else {
        this.vitesse4 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type moteur_array
    // Serialize message field [vitesse1]
    bufferOffset = _serializer.uint8(obj.vitesse1, buffer, bufferOffset);
    // Serialize message field [vitesse2]
    bufferOffset = _serializer.uint8(obj.vitesse2, buffer, bufferOffset);
    // Serialize message field [vitesse3]
    bufferOffset = _serializer.uint8(obj.vitesse3, buffer, bufferOffset);
    // Serialize message field [vitesse4]
    bufferOffset = _serializer.uint8(obj.vitesse4, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type moteur_array
    let len;
    let data = new moteur_array(null);
    // Deserialize message field [vitesse1]
    data.vitesse1 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vitesse2]
    data.vitesse2 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vitesse3]
    data.vitesse3 = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vitesse4]
    data.vitesse4 = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'raynov/moteur_array';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '07ec4db60710b788b706e3f593f03d57';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 vitesse1
    uint8 vitesse2
    uint8 vitesse3
    uint8 vitesse4
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new moteur_array(null);
    if (msg.vitesse1 !== undefined) {
      resolved.vitesse1 = msg.vitesse1;
    }
    else {
      resolved.vitesse1 = 0
    }

    if (msg.vitesse2 !== undefined) {
      resolved.vitesse2 = msg.vitesse2;
    }
    else {
      resolved.vitesse2 = 0
    }

    if (msg.vitesse3 !== undefined) {
      resolved.vitesse3 = msg.vitesse3;
    }
    else {
      resolved.vitesse3 = 0
    }

    if (msg.vitesse4 !== undefined) {
      resolved.vitesse4 = msg.vitesse4;
    }
    else {
      resolved.vitesse4 = 0
    }

    return resolved;
    }
};

module.exports = moteur_array;

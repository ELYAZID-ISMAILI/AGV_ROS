// Auto-generated. Do not edit!

// (in-package raynov.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class localisation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.dist_A = null;
      this.sens_A = null;
      this.dist_B = null;
      this.sens_B = null;
      this.dist_C = null;
      this.sens_C = null;
      this.dist_D = null;
      this.sens_D = null;
      this.dist_AB = null;
      this.dist_AC = null;
      this.dist_AD = null;
      this.dist_BC = null;
      this.dist_BD = null;
      this.dist_CD = null;
    }
    else {
      if (initObj.hasOwnProperty('dist_A')) {
        this.dist_A = initObj.dist_A
      }
      else {
        this.dist_A = 0.0;
      }
      if (initObj.hasOwnProperty('sens_A')) {
        this.sens_A = initObj.sens_A
      }
      else {
        this.sens_A = false;
      }
      if (initObj.hasOwnProperty('dist_B')) {
        this.dist_B = initObj.dist_B
      }
      else {
        this.dist_B = 0.0;
      }
      if (initObj.hasOwnProperty('sens_B')) {
        this.sens_B = initObj.sens_B
      }
      else {
        this.sens_B = false;
      }
      if (initObj.hasOwnProperty('dist_C')) {
        this.dist_C = initObj.dist_C
      }
      else {
        this.dist_C = 0.0;
      }
      if (initObj.hasOwnProperty('sens_C')) {
        this.sens_C = initObj.sens_C
      }
      else {
        this.sens_C = false;
      }
      if (initObj.hasOwnProperty('dist_D')) {
        this.dist_D = initObj.dist_D
      }
      else {
        this.dist_D = 0.0;
      }
      if (initObj.hasOwnProperty('sens_D')) {
        this.sens_D = initObj.sens_D
      }
      else {
        this.sens_D = false;
      }
      if (initObj.hasOwnProperty('dist_AB')) {
        this.dist_AB = initObj.dist_AB
      }
      else {
        this.dist_AB = 0.0;
      }
      if (initObj.hasOwnProperty('dist_AC')) {
        this.dist_AC = initObj.dist_AC
      }
      else {
        this.dist_AC = 0.0;
      }
      if (initObj.hasOwnProperty('dist_AD')) {
        this.dist_AD = initObj.dist_AD
      }
      else {
        this.dist_AD = 0.0;
      }
      if (initObj.hasOwnProperty('dist_BC')) {
        this.dist_BC = initObj.dist_BC
      }
      else {
        this.dist_BC = 0.0;
      }
      if (initObj.hasOwnProperty('dist_BD')) {
        this.dist_BD = initObj.dist_BD
      }
      else {
        this.dist_BD = 0.0;
      }
      if (initObj.hasOwnProperty('dist_CD')) {
        this.dist_CD = initObj.dist_CD
      }
      else {
        this.dist_CD = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type localisation
    // Serialize message field [dist_A]
    bufferOffset = _serializer.float64(obj.dist_A, buffer, bufferOffset);
    // Serialize message field [sens_A]
    bufferOffset = _serializer.bool(obj.sens_A, buffer, bufferOffset);
    // Serialize message field [dist_B]
    bufferOffset = _serializer.float64(obj.dist_B, buffer, bufferOffset);
    // Serialize message field [sens_B]
    bufferOffset = _serializer.bool(obj.sens_B, buffer, bufferOffset);
    // Serialize message field [dist_C]
    bufferOffset = _serializer.float64(obj.dist_C, buffer, bufferOffset);
    // Serialize message field [sens_C]
    bufferOffset = _serializer.bool(obj.sens_C, buffer, bufferOffset);
    // Serialize message field [dist_D]
    bufferOffset = _serializer.float64(obj.dist_D, buffer, bufferOffset);
    // Serialize message field [sens_D]
    bufferOffset = _serializer.bool(obj.sens_D, buffer, bufferOffset);
    // Serialize message field [dist_AB]
    bufferOffset = _serializer.float64(obj.dist_AB, buffer, bufferOffset);
    // Serialize message field [dist_AC]
    bufferOffset = _serializer.float64(obj.dist_AC, buffer, bufferOffset);
    // Serialize message field [dist_AD]
    bufferOffset = _serializer.float64(obj.dist_AD, buffer, bufferOffset);
    // Serialize message field [dist_BC]
    bufferOffset = _serializer.float64(obj.dist_BC, buffer, bufferOffset);
    // Serialize message field [dist_BD]
    bufferOffset = _serializer.float64(obj.dist_BD, buffer, bufferOffset);
    // Serialize message field [dist_CD]
    bufferOffset = _serializer.float64(obj.dist_CD, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type localisation
    let len;
    let data = new localisation(null);
    // Deserialize message field [dist_A]
    data.dist_A = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sens_A]
    data.sens_A = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dist_B]
    data.dist_B = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sens_B]
    data.sens_B = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dist_C]
    data.dist_C = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sens_C]
    data.sens_C = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dist_D]
    data.dist_D = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sens_D]
    data.sens_D = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dist_AB]
    data.dist_AB = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_AC]
    data.dist_AC = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_AD]
    data.dist_AD = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_BC]
    data.dist_BC = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_BD]
    data.dist_BD = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [dist_CD]
    data.dist_CD = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 84;
  }

  static datatype() {
    // Returns string type for a message object
    return 'raynov/localisation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7dd2e3ad49ccb3008add62bf1f0bd723';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 dist_A
    bool sens_A
    float64 dist_B
    bool sens_B
    float64 dist_C
    bool sens_C
    float64 dist_D
    bool sens_D
    float64 dist_AB
    float64 dist_AC
    float64 dist_AD
    float64 dist_BC
    float64 dist_BD
    float64 dist_CD
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new localisation(null);
    if (msg.dist_A !== undefined) {
      resolved.dist_A = msg.dist_A;
    }
    else {
      resolved.dist_A = 0.0
    }

    if (msg.sens_A !== undefined) {
      resolved.sens_A = msg.sens_A;
    }
    else {
      resolved.sens_A = false
    }

    if (msg.dist_B !== undefined) {
      resolved.dist_B = msg.dist_B;
    }
    else {
      resolved.dist_B = 0.0
    }

    if (msg.sens_B !== undefined) {
      resolved.sens_B = msg.sens_B;
    }
    else {
      resolved.sens_B = false
    }

    if (msg.dist_C !== undefined) {
      resolved.dist_C = msg.dist_C;
    }
    else {
      resolved.dist_C = 0.0
    }

    if (msg.sens_C !== undefined) {
      resolved.sens_C = msg.sens_C;
    }
    else {
      resolved.sens_C = false
    }

    if (msg.dist_D !== undefined) {
      resolved.dist_D = msg.dist_D;
    }
    else {
      resolved.dist_D = 0.0
    }

    if (msg.sens_D !== undefined) {
      resolved.sens_D = msg.sens_D;
    }
    else {
      resolved.sens_D = false
    }

    if (msg.dist_AB !== undefined) {
      resolved.dist_AB = msg.dist_AB;
    }
    else {
      resolved.dist_AB = 0.0
    }

    if (msg.dist_AC !== undefined) {
      resolved.dist_AC = msg.dist_AC;
    }
    else {
      resolved.dist_AC = 0.0
    }

    if (msg.dist_AD !== undefined) {
      resolved.dist_AD = msg.dist_AD;
    }
    else {
      resolved.dist_AD = 0.0
    }

    if (msg.dist_BC !== undefined) {
      resolved.dist_BC = msg.dist_BC;
    }
    else {
      resolved.dist_BC = 0.0
    }

    if (msg.dist_BD !== undefined) {
      resolved.dist_BD = msg.dist_BD;
    }
    else {
      resolved.dist_BD = 0.0
    }

    if (msg.dist_CD !== undefined) {
      resolved.dist_CD = msg.dist_CD;
    }
    else {
      resolved.dist_CD = 0.0
    }

    return resolved;
    }
};

module.exports = localisation;

// Auto-generated. Do not edit!

// (in-package raynov.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class magnetique {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ligne1 = null;
      this.ligne2 = null;
      this.ligne3 = null;
    }
    else {
      if (initObj.hasOwnProperty('ligne1')) {
        this.ligne1 = initObj.ligne1
      }
      else {
        this.ligne1 = false;
      }
      if (initObj.hasOwnProperty('ligne2')) {
        this.ligne2 = initObj.ligne2
      }
      else {
        this.ligne2 = false;
      }
      if (initObj.hasOwnProperty('ligne3')) {
        this.ligne3 = initObj.ligne3
      }
      else {
        this.ligne3 = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type magnetique
    // Serialize message field [ligne1]
    bufferOffset = _serializer.bool(obj.ligne1, buffer, bufferOffset);
    // Serialize message field [ligne2]
    bufferOffset = _serializer.bool(obj.ligne2, buffer, bufferOffset);
    // Serialize message field [ligne3]
    bufferOffset = _serializer.bool(obj.ligne3, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type magnetique
    let len;
    let data = new magnetique(null);
    // Deserialize message field [ligne1]
    data.ligne1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [ligne2]
    data.ligne2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [ligne3]
    data.ligne3 = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'raynov/magnetique';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3edf45c64f20ac694c042274e32fac81';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool ligne1
    bool ligne2
    bool ligne3 
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new magnetique(null);
    if (msg.ligne1 !== undefined) {
      resolved.ligne1 = msg.ligne1;
    }
    else {
      resolved.ligne1 = false
    }

    if (msg.ligne2 !== undefined) {
      resolved.ligne2 = msg.ligne2;
    }
    else {
      resolved.ligne2 = false
    }

    if (msg.ligne3 !== undefined) {
      resolved.ligne3 = msg.ligne3;
    }
    else {
      resolved.ligne3 = false
    }

    return resolved;
    }
};

module.exports = magnetique;

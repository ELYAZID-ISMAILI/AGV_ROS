
"use strict";

let moteur_array = require('./moteur_array.js');
let encodeur = require('./encodeur.js');
let magnetique = require('./magnetique.js');
let sonar = require('./sonar.js');
let localisation = require('./localisation.js');
let gyroscope = require('./gyroscope.js');

module.exports = {
  moteur_array: moteur_array,
  encodeur: encodeur,
  magnetique: magnetique,
  sonar: sonar,
  localisation: localisation,
  gyroscope: gyroscope,
};

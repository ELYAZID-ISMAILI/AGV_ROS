// Auto-generated. Do not edit!

// (in-package raynov.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class sonar {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.obstacle = null;
      this.distance_obstacle = null;
    }
    else {
      if (initObj.hasOwnProperty('obstacle')) {
        this.obstacle = initObj.obstacle
      }
      else {
        this.obstacle = false;
      }
      if (initObj.hasOwnProperty('distance_obstacle')) {
        this.distance_obstacle = initObj.distance_obstacle
      }
      else {
        this.distance_obstacle = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sonar
    // Serialize message field [obstacle]
    bufferOffset = _serializer.bool(obj.obstacle, buffer, bufferOffset);
    // Serialize message field [distance_obstacle]
    bufferOffset = _serializer.float64(obj.distance_obstacle, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sonar
    let len;
    let data = new sonar(null);
    // Deserialize message field [obstacle]
    data.obstacle = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [distance_obstacle]
    data.distance_obstacle = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'raynov/sonar';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '18f57951b0b4fc442c6a82559adfa1d2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool obstacle
    float64 distance_obstacle
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sonar(null);
    if (msg.obstacle !== undefined) {
      resolved.obstacle = msg.obstacle;
    }
    else {
      resolved.obstacle = false
    }

    if (msg.distance_obstacle !== undefined) {
      resolved.distance_obstacle = msg.distance_obstacle;
    }
    else {
      resolved.distance_obstacle = 0.0
    }

    return resolved;
    }
};

module.exports = sonar;

#!/usr/bin/env python

import smtplib
#ros import
import rospy
from raynov.msg import encodeur
from raynov.msg import gyroscope
from raynov.msg import localisation
from raynov.msg import magnetique
from raynov.msg import sonar
from raynov.msg import moteur_array

#sqlite import
import sqlite3
import os
import time
#Global variables
speriod=(1.5)
dbname='/home/pi/Raynov/User.db'

#Action= str(row[0])
#ZonneDep=str(row[1])
#ZonneArr=str(row[2])

def recuperer_commande():
	conn=sqlite3.connect(dbname)
	curs=conn.cursor()
	row=curs.execute("SELECT TOP 1 * FROM AddCommand")
	conn.close()
	return str(row[0]),str(row[1]),str(row[2])
	
def changer_du_sens():
	moteur_array.vitesse1=0
	moteur_array.vitesse2=255
	moteur_array.vitesse3=0
	moteur_array.vitesse4=255
	time.sleep(0.5)
	while magnetique.ligne1 !=0 and magnetique.ligne2 !=0 and magnetique.ligne3 !=0 :
		moteur_array.vitesse1=0
		moteur_array.vitesse2=255
		moteur_array.vitesse3=0
		moteur_array.vitesse4=255		
	moteur_array.vitesse1=0
	moteur_array.vitesse2=0
	moteur_array.vitesse3=0
	moteur_array.vitesse4=0
	
def estimer_distance(zone1,zone2):
	if zone1==zoneA and zone2=zoneB:
		distance=localisation.dist_A + localisation.dist_AB
	elif zone1==zoneA and zone2=zoneC:
		distance=localisation.dist_A + localisation.dist_AC
	elif zone1==zoneA and zone2=zoneD:
		distance=localisation.dist_A + localisation.dist_AD
	elif zone1==zoneB and zone2=zoneC:
		distance=localisation.dist_B + localisation.dist_BC
	elif zone1==zoneB and zone2=zoneD:
		distance=localisation.dist_B + localisation.dist_BD
	elif zone1==zoneB and zone2=zoneA:
		distance=localisation.dist_B + localisation.dist_AB
	elif zone1==zoneC and zone2=zoneB:
		distance=localisation.dist_C + localisation.dist_BC
	elif zone1==zoneC and zone2=zoneA:
		distance=localisation.dist_C + localisation.dist_AC
	elif zone1==zoneC and zone2=zoneD:
		distance=localisation.dist_C + localisation.dist_CD
	elif zone1==zoneD and zone2=zoneA:
		distance=localisation.dist_D + localisation.dist_AD
	elif zone1==zoneD and zone2=zoneB:
		distance=localisation.dist_D + localisation.dist_BD
	elif zone1==zoneD and zone2=zoneC:
		distance=localisation.dist_D + localisation.dist_CD
	else:
		distance=0
	return distance
	
def Aller_zone(X):
	if X==zoneA :
		if sens_A==1 :
			changer_du_sens()
		while encodeur.sum < dist_A :
			executer()
	elif X==zoneB :
		if sens_B==1 :
			changer_du_sens()
		while encodeur.sum < dist_B :
			executer()
	elif X==zoneB :
		if sens_C==1 :
			changer_du_sens()
		while encodeur.sum < dist_C :
			executer() 
	else :
		if sens_D==1 :
			changer_du_sens()
		while encodeur.sum < dist_D :
			executer() 
			
def executer()
	Gerer_obstacle()
	if magnetique.ligne2==1 :
		if magnetique.ligne1==1 :
			tourner_droite()
			time.sleep(0.1)
		elif magnetique.ligne3==1 :
			tourner_gauche()
			time.sleep(0.1)
		else:
			avancer()
			time.sleep(0.1)
		elif magnetique.ligne1==1 :
			tourner_droite()
			time.sleep(0.1)
		else:
			tourner_gauche()
			time.sleep(0.1)

def Aller_se_charger():
	if sens_C==0:
		changer_du_sens()
	if magnetique.ligne2 == 1 :
		Gerer_obstacle()
		avancer()
	elif magnetique.ligne1 == 1 :
		Gerer_obstacle()
		avancer_droite()
	else magnetique.ligne3 == 1 :
		Gerer_obstacle()
		avancer_gauche()

def stop():
	moteur_array.vitesse1=0
	moteur_array.vitesse2=0
	moteur_array.vitesse3=0
	moteur_array.vitesse4=0

def tourner_droite()
	moteur_array.vitesse1=255
	moteur_array.vitesse2=150
	moteur_array.vitesse3=255
	moteur_array.vitesse4=150
	
def tourner_gauche()
	moteur_array.vitesse1=150
	moteur_array.vitesse2=255
	moteur_array.vitesse3=150
	moteur_array.vitesse4=255

def avancer()
	moteur_array.vitesse1=255
	moteur_array.vitesse2=255
	moteur_array.vitesse3=255
	moteur_array.vitesse4=255

def Gerer_obstacle():
	i=0
	while distance < 10:
		distance=sonar.distance_obstacle
		stop()
		time.sleep(1)
		i++
		if i==900 :
			envoyer_email()
		


def envoyer_email(msg)
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.connect("smtp.example.com",465)
	#Ensuite, connectez-vous au serveur Gmail
	server.login("m.serbouti@raynov.ma", "raynov")
	#Le message à envoyer
	#Envoyez le mail
	server.sendmail("m.serbouti@raynov.ma", "m.serbouti@raynov.ma" msg)
	server.quit()

def main():
	Action,ZoneDep,ZoneArr=recuperer_commande()
	if dist_battrie < dist_zondep + dist_DepArr :
		Aller_se_charger()
	else :
		Aller_zone(ZoneDep)
		executer(Action)
		Aller(ZoneArr)
		executer(Action)
	

def callback(data):
	rospy.loginfo("")
    
def listener():
    rospy.init_node('traitement', anonymous=True)


if __name__ == "__main__":
    # execute only if run as a script
    main()
